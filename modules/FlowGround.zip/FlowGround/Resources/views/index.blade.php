@extends('layouts.app', ['title' => __('WhatsApp Flow Management')])

@section('head')
<style>
    /* Single content padding so header and body align */
    :root { --fg-content-padding: 1.5rem; }

    .flowground-wrap { padding-top: 5.6rem; padding-bottom: 1.5rem; }
    .flowground-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,.06);
        width: 100%;
    }

    /* ========== HEADER – aligned with body content ========== */
    .flowground-page-header {
        padding: 1.75rem var(--fg-content-padding) 1.5rem;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
    }
    .flowground-page-header .flowground-top {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .flowground-page-header .page-title {
        font-size: 1.35rem;
        font-weight: 700;
        color: #0f172a;
        letter-spacing: -0.02em;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .flowground-page-header .page-title .icon-wrap {
        width: 42px;
        height: 42px;
        border-radius: 10px;
        background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.1rem;
        flex-shrink: 0;
    }
    .flowground-page-header .page-title .count {
        font-weight: 500;
        color: #64748b;
        font-size: 0.875rem;
    }
    .flowground-toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 0.75rem; }
    .flowground-search-wrap { position: relative; width: 240px; }
    .flowground-search-wrap input {
        padding-left: 2.5rem;
        border-radius: 8px;
        border: 1px solid #e2e8f0;
        font-size: 0.875rem;
        height: 40px;
    }
    .flowground-search-wrap input:focus {
        border-color: #0d9488;
        box-shadow: 0 0 0 2px rgba(13, 148, 136, 0.15);
    }
    .flowground-search-wrap .search-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 0.95rem;
        pointer-events: none;
    }
    .flowground-actions .btn-primary-flow {
        background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 600;
        font-size: 0.875rem;
        height: 40px;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
    }
    .flowground-actions .btn-primary-flow:hover {
        color: #fff;
        opacity: 0.95;
        transform: translateY(-1px);
    }
    .flowground-actions .dropdown-menu {
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 10px 40px rgba(0,0,0,.1);
        padding: 0.5rem;
    }
    .flowground-actions .dropdown-item {
        border-radius: 6px;
        padding: 0.5rem 0.875rem;
        font-size: 0.875rem;
    }
    .flowground-actions .dropdown-item:hover { background: #f0fdfa; color: #0f766e; }

    /* ========== BODY – same horizontal padding as header ========== */
    .flowground-body {
        padding: 0;
        background: #f8fafc;
        min-height: 200px;
    }
    .flowground-flash { padding: 1rem var(--fg-content-padding) 0; }
    .flowground-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
        padding: var(--fg-content-padding);
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        background: #f8fafc;
    }
    @media (max-width: 768px) { .flowground-stats { grid-template-columns: 1fr; } }
    .flowground-stat-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 1.25rem 1.25rem;
        transition: box-shadow .2s, border-color .2s;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .flowground-stat-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,.08);
        border-color: #cbd5e1;
    }
    .flowground-stat-card .value { font-size: 1.75rem; font-weight: 700; color: #0f172a; line-height: 1.2; }
    .flowground-stat-card .label { font-size: 0.8125rem; color: #64748b; margin-top: 0.25rem; font-weight: 500; }
    .flowground-stat-card.published .value { color: #059669; }
    .flowground-stat-card.draft .value { color: #d97706; }

    /* ========== TABLE SECTION – same content padding ========== */
    .flowground-table-section {
        margin: 0 var(--fg-content-padding) 1.5rem;
        background: #fff;
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
        overflow: hidden;
    }
    .flowground-table-heading {
        padding: 1.25rem 1.25rem;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
    }
    .flowground-table-heading .heading-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .flowground-table-heading h3 {
        margin: 0;
        font-size: 1rem;
        font-weight: 600;
        color: #0f172a;
        letter-spacing: -0.01em;
    }
    .flowground-table-heading .filter-select {
        border-radius: 6px;
        border: 1px solid #e2e8f0;
        padding: 0.5rem 0.75rem;
        font-size: 0.8125rem;
        color: #475569;
        background: #fff;
    }
    .flowground-table-divider { display: none; }
    .flowground-table { padding: 0; }
    .flowground-table table { margin: 0; border-collapse: collapse; }
    .flowground-table thead th {
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: #64748b;
        padding: 0.875rem 1.25rem;
        border-bottom: 1px solid #e2e8f0;
        background: #f8fafc;
    }
    .flowground-table thead th:first-child { padding-left: 1.25rem; }
    .flowground-table thead th:last-child { padding-right: 1.25rem; }
    .flowground-table tbody td {
        padding: 1rem 1.25rem;
        font-size: 0.875rem;
        vertical-align: middle;
        border-bottom: 1px solid #f1f5f9;
    }
    .flowground-table tbody tr:nth-child(even) { background: #fafbfc; }
    .flowground-table tbody tr:hover { background: #f0fdfa !important; }
    .flowground-table tbody tr:last-child td { border-bottom: none; }
    .flowground-table .flow-cell { display: flex; align-items: center; flex-wrap: wrap; gap: 0.75rem; }
    .flowground-table .flow-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: linear-gradient(135deg, #ccfbf1 0%, #99f6e4 100%);
        color: #0d9488;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.05rem;
        flex-shrink: 0;
    }
    .flowground-table .flow-name { font-weight: 600; color: #0f172a; }
    .flowground-table .flow-id { font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem; display: block; }
    .badge-status {
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        padding: 0.35rem 0.7rem;
        border-radius: 6px;
    }
    .badge-status.published { background: #d1fae5; color: #047857; }
    .badge-status.draft { background: #ffedd5; color: #c2410c; }
    .flowground-table .actions-cell { display: inline-flex; align-items: center; gap: 0.5rem; }
    .flowground-table .btn-action {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        border: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #64748b;
        transition: all .15s;
    }
    .flowground-table .btn-action:hover { background: #f1f5f9; color: #1e293b; }
    .flowground-table .btn-action.edit:hover { background: #d1fae5; color: #059669; }
    .flowground-table .btn-action.delete:hover { background: #fee2e2; color: #dc2626; }
    .flowground-empty {
        text-align: center;
        padding: 3rem 1.25rem;
        color: #64748b;
        font-size: 0.9375rem;
        line-height: 1.5;
    }
    .flowground-empty a { color: #0d9488; font-weight: 600; }
    .flowground-pagination {
        padding: 1rem var(--fg-content-padding);
        background: #fff;
        border-top: 1px solid #e2e8f0;
    }
</style>
@endsection

@section('content')
<div class="container-fluid flowground-wrap">
    <div class="flowground-card">
        <header class="flowground-page-header">
            <div class="flowground-top">
                <h1 class="page-title">
                    <span class="icon-wrap"><i class="ni ni-send"></i></span>
                    {{ __('WhatsApp Flow Management') }}
                    <span class="count">({{ $flows->total() }} {{ __('Flows') }})</span>
                </h1>
                <div class="flowground-toolbar">
                    <form action="{{ route('flow-ground.index') }}" method="GET" class="d-flex flex-wrap align-items-center gap-2">
                        <input type="hidden" name="status" value="{{ request('status') }}">
                        <div class="flowground-search-wrap">
                            <i class="ni ni-zoom-split-in search-icon"></i>
                            <input type="search" name="search" class="form-control" placeholder="{{ __('Search flows...') }}" value="{{ request('search') }}">
                        </div>
                        <div class="flowground-actions dropdown">
                            <button class="btn btn-primary-flow dropdown-toggle" type="button" id="flowActionsDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="ni ni-fat-add"></i> {{ __('Flow Actions') }}
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="flowActionsDropdown">
                                <a class="dropdown-item" href="{{ route('flow-ground.create') }}"><i class="ni ni-fat-add mr-2"></i> {{ __('Create New') }}</a>
                                <a class="dropdown-item" href="{{ route('flow-ground.sync') }}"><i class="ni ni-refresh mr-2"></i> {{ __('Sync from Meta') }}</a>
                                <a class="dropdown-item" href="{{ route('flow-ground.view_data') }}"><i class="ni ni-chart-bar-32 mr-2"></i> {{ __('View Flow Data') }}</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </header>

        <div class="flowground-body">
            <div class="flowground-flash">@include('partials.flash')</div>

            <div class="flowground-stats">
                <div class="flowground-stat-card total">
                    <div class="value">{{ $total }}</div>
                    <div class="label">{{ __('Total Flows') }}</div>
                </div>
                <div class="flowground-stat-card published">
                    <div class="value">{{ $published }}</div>
                    <div class="label">{{ __('Published') }}</div>
                </div>
                <div class="flowground-stat-card draft">
                    <div class="value">{{ $draft }}</div>
                    <div class="label">{{ __('Draft') }}</div>
                </div>
            </div>

            <section class="flowground-table-section">
                <div class="flowground-table-heading">
                    <div class="heading-row">
                        <h3>{{ __('All Flows') }}</h3>
                        <form action="{{ route('flow-ground.index') }}" method="GET" class="d-inline">
                            @if(request('search'))<input type="hidden" name="search" value="{{ request('search') }}">@endif
                            <select name="status" class="filter-select" onchange="this.form.submit()">
                                <option value="">{{ __('All statuses') }}</option>
                                <option value="published" {{ request('status') == 'published' ? 'selected' : '' }}>{{ __('Published') }}</option>
                                <option value="draft" {{ request('status') == 'draft' ? 'selected' : '' }}>{{ __('Draft') }}</option>
                            </select>
                        </form>
                    </div>
                </div>
                <div class="flowground-table-divider"></div>
                <div class="flowground-table">
                    <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th style="width: 60px;">#</th>
                                <th>{{ __('Flow') }}</th>
                                <th>{{ __('Status') }}</th>
                                <th>{{ __('Submissions') }}</th>
                                <th class="text-right" style="width: 160px;">{{ __('Actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($flows as $index => $flow)
                            <tr>
                                <td class="text-muted">{{ $flows->firstItem() + $index }}</td>
                                <td>
                                    <div class="flow-cell">
                                        <span class="flow-icon"><i class="ni ni-chat-round"></i></span>
                                        <span>
                                            <span class="flow-name">{{ $flow->name }}</span>
                                            @if($flow->meta_flow_id)
                                                <span class="flow-id">{{ $flow->meta_flow_id }}</span>
                                            @endif
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    @if(isset($flow->status) && $flow->status == 'published')
                                        <span class="badge-status published">{{ __('Published') }}</span>
                                    @else
                                        <span class="badge-status draft">{{ __('Draft') }}</span>
                                    @endif
                                </td>
                                <td>
                                    @php
                                        $count = isset($dataCounts[$flow->id]) ? (int) $dataCounts[$flow->id] : 0;
                                    @endphp
                                    @if($count > 0)
                                        <a href="{{ route('flow-ground.data', $flow) }}" class="text-decoration-none">
                                            <span class="badge bg-primary">{{ $count }}</span>
                                        </a>
                                    @else
                                        <span class="text-muted">0</span>
                                    @endif
                                </td>
                                <td class="text-right">
                                    <div class="actions-cell">
                                        @if(isset($flow->status) && $flow->status === 'draft' && !empty($flow->meta_flow_id))
                                            <a href="{{ route('flow-ground.publish', $flow) }}" class="btn-action" title="{{ __('Publish') }}"><i class="ni ni-send"></i></a>
                                        @endif
                                        <a href="{{ route('flow-ground.data', $flow) }}" class="btn-action" title="{{ __('View data') }}"><i class="ni ni-chart-bar-32"></i></a>
                                        <!-- <a href="{{ route('flow-ground.edit', $flow) }}" class="btn-action edit" title="{{ __('Edit') }}"><i class="ni ni-settings"></i></a> -->
                                        <form action="{{ route('flow-ground.destroy', $flow) }}" method="GET" class="d-inline" onsubmit="return confirm('{{ __('Are you sure you want to delete this flow?') }}');">
                                            <button type="submit" class="btn-action delete" title="{{ __('Delete') }}"><i class="ni ni-fat-remove"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="flowground-empty">
                                    {{ __('No flows yet.') }} <a href="{{ route('flow-ground.create') }}">{{ __('Create New') }}</a> {{ __('or') }} <a href="{{ route('flow-ground.sync') }}">{{ __('Sync from Meta') }}</a>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                    </div>
                </div>
            </section>

            @if($flows->hasPages())
            <div class="flowground-pagination">
                {{ $flows->appends(request()->query())->links() }}
            </div>
            @endif
        </div>
    </div>
</div>
@endsection
