@extends('layouts.app', ['title' => __('Flow Data')])
@section('head')
@section('head')
<style>
    /* Single content padding so header and body align */
    :root { --fg-content-padding: 1.5rem; }

    .flowground-wrap { padding-top: 5.6rem; padding-bottom: 1.5rem; }
    .flowground-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,.06);
        width: 100%;
    }

    /* ========== HEADER – aligned with body content ========== */
    .flowground-page-header {
        padding: 1.75rem var(--fg-content-padding) 1.5rem;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
    }
    .flowground-page-header .flowground-top {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .flowground-page-header .page-title {
        font-size: 1.35rem;
        font-weight: 700;
        color: #0f172a;
        letter-spacing: -0.02em;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .flowground-page-header .page-title .icon-wrap {
        width: 42px;
        height: 42px;
        border-radius: 10px;
        background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.1rem;
        flex-shrink: 0;
    }
    .flowground-page-header .page-title .count {
        font-weight: 500;
        color: #64748b;
        font-size: 0.875rem;
    }
    .flowground-toolbar { display: flex; flex-wrap: wrap; align-items: center; gap: 0.75rem; }
    .flowground-search-wrap { position: relative; width: 240px; }
    .flowground-search-wrap input {
        padding-left: 2.5rem;
        border-radius: 8px;
        border: 1px solid #e2e8f0;
        font-size: 0.875rem;
        height: 40px;
    }
    .flowground-search-wrap input:focus {
        border-color: #0d9488;
        box-shadow: 0 0 0 2px rgba(13, 148, 136, 0.15);
    }
    .flowground-search-wrap .search-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 0.95rem;
        pointer-events: none;
    }
    .flowground-actions .btn-primary-flow {
        background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 600;
        font-size: 0.875rem;
        height: 40px;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
    }
    .flowground-actions .btn-primary-flow:hover {
        color: #fff;
        opacity: 0.95;
        transform: translateY(-1px);
    }
    .flowground-actions .dropdown-menu {
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 10px 40px rgba(0,0,0,.1);
        padding: 0.5rem;
    }
    .flowground-actions .dropdown-item {
        border-radius: 6px;
        padding: 0.5rem 0.875rem;
        font-size: 0.875rem;
    }
    .flowground-actions .dropdown-item:hover { background: #f0fdfa; color: #0f766e; }

    /* ========== BODY – same horizontal padding as header ========== */
    .flowground-body {
        padding: 0;
        background: #f8fafc;
        min-height: 200px;
    }
    .flowground-flash { padding: 1rem var(--fg-content-padding) 0; }
    .flowground-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
        padding: var(--fg-content-padding);
        padding-top: 1.5rem;
        padding-bottom: 1.5rem;
        background: #f8fafc;
    }
    @media (max-width: 768px) { .flowground-stats { grid-template-columns: 1fr; } }
    .flowground-stat-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 1.25rem 1.25rem;
        transition: box-shadow .2s, border-color .2s;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .flowground-stat-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,.08);
        border-color: #cbd5e1;
    }
    .flowground-stat-card .value { font-size: 1.75rem; font-weight: 700; color: #0f172a; line-height: 1.2; }
    .flowground-stat-card .label { font-size: 0.8125rem; color: #64748b; margin-top: 0.25rem; font-weight: 500; }
    .flowground-stat-card.published .value { color: #059669; }
    .flowground-stat-card.draft .value { color: #d97706; }

    /* ========== TABLE SECTION – same content padding ========== */
    .flowground-table-section {
        margin: 0 var(--fg-content-padding) 1.5rem;
        background: #fff;
        border-radius: 10px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 2px rgba(0,0,0,.04);
        overflow: hidden;
    }
    .flowground-table-heading {
        padding: 1.25rem 1.25rem;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
    }
    .flowground-table-heading .heading-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
    }
    .flowground-table-heading h3 {
        margin: 0;
        font-size: 1rem;
        font-weight: 600;
        color: #0f172a;
        letter-spacing: -0.01em;
    }
    .flowground-table-heading .filter-select {
        border-radius: 6px;
        border: 1px solid #e2e8f0;
        padding: 0.5rem 0.75rem;
        font-size: 0.8125rem;
        color: #475569;
        background: #fff;
    }
    .flowground-table-divider { display: none; }
    .flowground-table { padding: 0; }
    .flowground-table table { margin: 0; border-collapse: collapse; }
    .flowground-table thead th {
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: #64748b;
        padding: 0.875rem 1.25rem;
        border-bottom: 1px solid #e2e8f0;
        background: #f8fafc;
    }
    .flowground-table thead th:first-child { padding-left: 1.25rem; }
    .flowground-table thead th:last-child { padding-right: 1.25rem; }
    .flowground-table tbody td {
        padding: 1rem 1.25rem;
        font-size: 0.875rem;
        vertical-align: middle;
        border-bottom: 1px solid #f1f5f9;
    }
    .flowground-table tbody tr:nth-child(even) { background: #fafbfc; }
    .flowground-table tbody tr:hover { background: #f0fdfa !important; }
    .flowground-table tbody tr:last-child td { border-bottom: none; }
    .flowground-table .flow-cell { display: flex; align-items: center; flex-wrap: wrap; gap: 0.75rem; }
    .flowground-table .flow-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: linear-gradient(135deg, #ccfbf1 0%, #99f6e4 100%);
        color: #0d9488;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.05rem;
        flex-shrink: 0;
    }
    .flowground-table .flow-name { font-weight: 600; color: #0f172a; }
    .flowground-table .flow-id { font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem; display: block; }
    .badge-status {
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        padding: 0.35rem 0.7rem;
        border-radius: 6px;
    }
    .badge-status.published { background: #d1fae5; color: #047857; }
    .badge-status.draft { background: #ffedd5; color: #c2410c; }
    .flowground-table .actions-cell { display: inline-flex; align-items: center; gap: 0.5rem; }
    .flowground-table .btn-action {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        border: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #64748b;
        transition: all .15s;
    }
    .flowground-table .btn-action:hover { background: #f1f5f9; color: #1e293b; }
    .flowground-table .btn-action.edit:hover { background: #d1fae5; color: #059669; }
    .flowground-table .btn-action.delete:hover { background: #fee2e2; color: #dc2626; }
    .flowground-empty {
        text-align: center;
        padding: 3rem 1.25rem;
        color: #64748b;
        font-size: 0.9375rem;
        line-height: 1.5;
    }
    .flowground-empty a { color: #0d9488; font-weight: 600; }
    .flowground-pagination {
        padding: 1rem var(--fg-content-padding);
        background: #fff;
        border-top: 1px solid #e2e8f0;
    }
</style>
@section('content')
<div class="flowground-wrap"></div>
<div class="container-fluid mt-4">
    <div class="row mb-3">
        <div class="col-md-8">
            <h2 class="mb-0">{{ $flow->name }}</h2>
            @if($flow->meta_flow_id)
                <div class="text-muted small">Meta ID: {{ $flow->meta_flow_id }}</div>
            @endif
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('flow-ground.index') }}" class="btn btn-outline-secondary">
                &larr; {{ __('Back to flows') }}
            </a>
        </div>
    </div>

    @if(! $rows->count())
        <div class="card">
            <div class="card-body text-center py-5">
                <h5 class="mb-2">{{ __('No data yet for this flow.') }}</h5>
                <p class="text-muted mb-0">{{ __('Submissions will appear here once this flow is used.') }}</p>
            </div>
        </div>
    @else
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">{{ __('Latest submissions') }}</h5>
                <span class="badge bg-light text-muted">{{ $rows->count() }} {{ __('row(s)') }}</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th style="width: 80px;">#</th>
                                <th>{{ __('Created at') }}</th>
                                <th>{{ __('Data') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($rows as $i => $row)
                            <tr>
                                <td>{{ $i + 1 }}</td>
                                <td>{{ $row->created_at ?? '-' }}</td>
                                <td>
                                    <pre class="mb-0 small">{{ json_encode($row, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection

