<?php

return [
    'name' => 'Shopifylist'
];
