<?php

return [
    'name' => 'Pricing'
];
