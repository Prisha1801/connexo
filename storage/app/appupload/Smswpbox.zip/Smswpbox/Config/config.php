<?php

return [
    'name' => 'Smswpbox',
];
