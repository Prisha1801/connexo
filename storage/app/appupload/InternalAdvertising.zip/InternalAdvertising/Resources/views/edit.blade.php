@extends('layouts.app')

@section('content')
<div class="header pb-8 pt-5 pt-md-8">
    <div class="container-fluid">
        <div class="header-body">
            <h1 class="mb-3 mt--3">🎟️🎟️ {{__('internal_advertising.title_admin')}}</h1> {{__('internal_advertising.')}}
            <div class="row align-items-center pt-2">
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card-header border-0">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="mb-0">{{__('internal_advertising.add_ads')}}</h3>
                    </div>
                    <div class="col-4 text-right">
                        <a href="{{ route('internal_advertising.index') }}"
                            class="btn btn-sm btn-primary">{{__('Back')}}</a>
                    </div>
                </div>
            </div>

            <div class="col-12">
                @include('partials.flash')
            </div>

            <div class="card-footer py-4">
                <form action="{{ route('internal_advertising.update',['id' => $model->id]) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div id="form-group-enable" class="form-group focused">
                        <label class="fs-6 fw-semibold form-label mt-3" for="enable">{{__('internal_advertising.Habilitar')}} <span style="color: red">*</span></label>
                        <div class="input-group">
                            <div class="custom-control custom-radio mb-3 mr-3">
                                <input name="enable" class="custom-control-input" id="active"
                                @if (isset($model)) @if ($model->enable == 1) checked @endif @else checked
                                    @endif value="1" type="radio">
                                <label class="custom-control-label" for="active">{{__('internal_advertising.active')}}</label>
                            </div>
                            <div class="custom-control custom-radio mb-3">
                                <input name="enable" class="custom-control-input" id="inactive" value="0"
                                    @if (isset($model) && $model->enable == 0) checked @endif type="radio">
                                <label class="custom-control-label" for="inactive">{{__('internal_advertising.inactive')}}</label>
                            </div>
                        </div>
                        @error('enable')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>


                    <div id="form-group-media_type" class="form-group focused">
                        <label class="fs-6 fw-semibold form-label mt-3" for="media_type">{{__('internal_advertising.media_type')}} <span style="color: red">*</span></label>
                        <div class="input-group">
                            <select class="form-control form-control-alternative" id="media_type" name="media_type"
                            required>
                                <option value="">{{__('internal_advertising.select_type_media')}}</option>
                                <option value="Image" {{ old("media_type") ? (old("media_type") == "Image" ? "selected":"") : ($model->media_type == "Image" ? "selected":"") }}>{{__('internal_advertising.image')}}</option>
                                <option value="Video" {{ old("media_type") ? (old("media_type") == "Video" ? "selected":"") : ($model->media_type == "Video" ? "selected":"") }}>{{__('internal_advertising.video')}}</option>
                                <option value="Url_Media" {{ old("media_type") ? (old("media_type") == "Url_Media" ? "selected":"") : ($model->media_type == "Url_Media" ? "selected":"") }}>{{__('internal_advertising.url_to_media')}}</option>
                            </select>
                        </div>
                        @error('media_type')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="form-group-url_media" class="form-group d-none">
                        <label class="fs-6 fw-semibold form-label mt-3" for="url_media">{{__('internal_advertising.url_media')}} <span style="color: red">*</span></label>
                        <div class="input-group">                                    
                            <input type="text" class="form-control form-control" name="url_media" id="url_media" value="{{old('url_media') ? old('url_media') : $model->url_media}}" />
                        </div>
                        @error('url_media')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="form-group-file_media" class="form-group focused d-none">
                        <label class="fs-6 fw-semibold form-label mt-3" for="file_media">{{__('internal_advertising.upload_file')}} <span style="color: red">*</span></label>
                        <div class="input-group">                                    
                            <input type="file" class="form-control form-control" value="{{old('file_media') ? old('file_media') : $model->url_media}}" name="file_media" id="file_media"/>
                        </div>
                        @error('file_media')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="form-group-url_to_redirect" class="form-group focused">
                        <label class="fs-6 fw-semibold form-label mt-3" for="url_to_redirect">{{__('internal_advertising.url_to_redirect')}}</label>
                        <div class="input-group">
                            <input type="text" name="url_to_redirect" id="url_to_redirect" class="form-control form-control" value="{{old('url_to_redirect') ? old('url_to_redirect') : $model->url_to_redirect}}" placeholder="">
                        </div>
                        @error('url_to_redirect')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="form-group-start_date" class="form-group focused">
                        <label class="fs-6 fw-semibold form-label mt-3" for="start_date">{{__('internal_advertising.start_date')}}{{$model->start_date !== null ? ': '.$model->start_date->format('d-m-Y') : ''}}</label>
                        <div class="input-group">                            
                            <input type="date" class="form-control form-control" id="start_date" name="start_date" value="{{old('start_date') ? old('start_date') : $model->start_date}}">
                        </div>
                        @error('start_date')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="form-group-end_date" class="form-group focused">
                        <label class="fs-6 fw-semibold form-label mt-3" for="end_date">{{__('internal_advertising.end_date')}}{{$model->end_date !== null ? ': '.$model->end_date->format('d-m-Y') : ''}}</label>
                        <div class="input-group">
                            <input type="date" class="form-control form-control" id="end_date" name="end_date" value="{{old('end_date') ? old('end_date') : $model->end_date}}">
                        </div>
                        @error('end_date')
                            <div style="color: red">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-success mt-4">{{__('SAVE')}}</button>
                    </div>

                </form>
            </div>

        </div>
    </div>
</div>

<<script id="script{{strtotime("now")}}" language="JavaScript">
    window.addEventListener("DOMContentLoaded", (event) => {

        $('#media_type').on('change', function() {
            if(this.value == 'Image' || this.value == 'Video'){
                $('#form-group-file_media').removeClass('d-none');
                $('#form-group-file_media').addClass('d-block');

                $('#form-group-url_media').removeClass('d-block');
                $('#form-group-url_media').addClass('d-none');
            }else{
                $('#form-group-file_media').removeClass('d-block');
                $('#form-group-file_media').addClass('d-none');

                $('#form-group-url_media').removeClass('d-none');
                $('#form-group-url_media').addClass('d-block');
            }            
        });

        @error('file_media')
            $('#form-group-file_media').removeClass('d-none');
            $('#form-group-file_media').addClass('d-block');
        @enderror

        @if ($model->media_type == "Image" || $model->media_type == "Video")
            $('#form-group-file_media').removeClass('d-none');
            $('#form-group-file_media').addClass('d-block');
        @else
            $('#form-group-url_media').removeClass('d-none');
            $('#form-group-url_media').addClass('d-block');
        @endif

        @error('url_media')
            $('#form-group-url_media').removeClass('d-none');
            $('#form-group-url_media').addClass('d-block');
        @enderror
    });
</script>

@endsection