@extends('layouts.app')

@section('content')
<div class="header pb-8 pt-5 pt-md-8">
    <div class="container-fluid">
        <div class="header-body">
            <h1 class="mb-3 mt--3">🎟️🎟️ Gestión de publicidad interna</h1>
            <div class="row align-items-center pt-2">
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">

                        </div>
                        <div class="col-4 text-right">
                            <a href="{{ route('internal_advertising.create') }}"
                                class="btn btn-sm btn-primary">{{__('Add new')}}</a>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    @include('partials.flash')
                </div>
                
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">{{ __('internal_advertising.habilitado') }}</th>
                                <th scope="col">{{__('internal_advertising.media_type')}}</th>
                                <th scope="col">{{__('internal_advertising.ads')}}</th>
                                <th scope="col">{{__('internal_advertising.url_ads')}}</th>
                                <th scope="col">{{__('internal_advertising.actions')}}</th>
                            </tr>
                        </thead>
                        <tbody>                
                            @forelse ($items as $item)
                                @php
                                    if($item->media_type == 'Video' || $item->media_type == 'Image'){
                                        $mime = mime_content_type(public_path($item->url_media));
                                    }else{
                                        if (str_contains($item->url_media, 'youtube')) { 
                                            $mime ='video/youtube';
                                        }
                                        if (str_contains($item->url_media, 'vimeo')) { 
                                            $mime ='video/vimeo';
                                        }
                                    }
                                @endphp
                                <tr>
                                    <td>{{ $item->enable == 1 ? __('internal_advertising.active') : __('internal_advertising.inactive') }}</td>
                                    <td>{{ $item->media_type == 'Image' ? __('internal_advertising.image') : __('internal_advertising.video') }}</td>
                                    <td>
                                        <div class="align-items-center">  
                                            @if( $item->media_type == 'Image')
                                                <img src="{{asset($item->url_media)}}" width="320" height="180" />
                                            @elseif ($item->media_type == 'Video')
                                                <div class="player">
                                                    <video id="player-demo_{{$item->id}}" width="320" height="180" preload="auto" controls="controls" >
                                                        <source src="{{asset($item->url_media)}}" type="{{$mime}}">                                                        
                                                    </video>
                                                </div>                                                
                                            @else
                                                <div class="player">
                                                    <video id="player-demo_{{$item->id}}" width="320" height="180" preload="auto" controls="controls" >
                                                        <source src="{{$item->url_media}}" type="{{$mime}}">
                                                    </video>
                                                </div>
                                            @endif
                                        </div>
                                    </td>
                                    <td>

                                        @if($item->url_to_redirect !== null )
                                        <a href="{{ $item->url_to_redirect }}" target="_blank">{{__('internal_advertising.visit')}}</a>
                                        @else
                                            Sin link
                                        @endif
                                        
                                    </td>
                                    <td>                                        
                                        <a href="{{ route('internal_advertising.edit', $item->id) }}"
                                                class="btn btn-primary btn-sm ">{{ __('Edit') }}</a>
                                        <form action="{{ route('internal_advertising.delete', $item->id) }}"
                                            method="POST" class="d-inline"
                                            onsubmit="return confirm('Are you sure you want to delete this coupon?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                class="btn btn-danger btn-sm">{{ __('Delete') }}</button>
                                        </form>
                                    </td>
                                </tr>
                            @empty
                                <tr class="text-center">
                                    <td colspan="4">{{__('internal_advertising.not_ads_found')}}</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                    {{ $items->links() }}
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    window.addEventListener("DOMContentLoaded", (event) => {
        function loadScript(src) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = src;
            script.defer = false;
            script.async = true;
            document.body.appendChild(script);
        }

        function loadStyle(href) {
            var link = document.createElement('link');
            link.type = 'text/css';
            link.href = href;
            link.rel = 'stylesheet';
            document.head.appendChild(link);
        }

        loadStyle('https://cdnjs.cloudflare.com/ajax/libs/mediaelement/2.13.2/css/mediaelementplayer.min.css');
        loadScript('https://cdnjs.cloudflare.com/ajax/libs/mediaelement/2.13.2/js/mediaelement-and-player.min.js');

        setTimeout(() => {
            @foreach ($items as $item)
                //$('#player-demo_{{$item->id}}').mediaelementplayer();
                @if($item->media_type == 'Video' || $item->media_type == 'Url_Media')
                    var player_{{$item->id}} = new MediaElementPlayer('#player-demo_{{$item->id}}');
                @endif                
            @endforeach
        }, 1500);
    });
</script>

@endsection


