@hasrole('owner') 
@if ($internal_advertising['data']['show_data']==true)
    @php
        $item = $internal_advertising['data']['model_ads'];
        if($item->media_type == 'Video' || $item->media_type == 'Image'){
            $mime = mime_content_type(public_path($item->url_media));
        }else{
            if (str_contains($item->url_media, 'youtube')) { 
                $mime ='video/youtube';
            }
            if (str_contains($item->url_media, 'vimeo')) { 
                $mime ='video/vimeo';
            }
        }
    @endphp
    <div id="video_ads_container" class="col-xl-4 mb-7" 
        style="width: 100%; height: 100%; max-width: 400px; max-height: 400px;">       
        @if( $item->media_type == 'Image')
            <a href="{{ $item->url_to_redirect ? $item->url_to_redirect : '#' }}" target="_blank">
                <img src="{{asset($item->url_media)}}"
                    style="width: 100%; height: 100%; max-width: 400px; max-height: 400px; border-radius: 15px" />
            </a>            
        @elseif ($item->media_type == 'Video')
            <div class="player">
                <video width="400" height="400" style="border-radius: 15px" id="player_ads" preload="auto" controls="controls">
                    <source src="{{asset($item->url_media)}}" type="{{$mime}}" >                                                        
                </video>
            </div>                                                
        @else
            <div class="player">
                <video width="400" height="400" style="border-radius: 15px" id="player_ads" preload="auto" controls="controls">
                    <source src="{{$item->url_media}}" type="{{$mime}}" >
                </video>
            </div>
        @endif       
    </div>

    <script id="script{{strtotime("now")}}" language="JavaScript">
        window.addEventListener("DOMContentLoaded", (event) => {

            function loadScript(src) {
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.src = src;
                script.defer = false;
                script.async = true;
                document.body.appendChild(script);
            }
    
            function loadStyle(href) {
                var link = document.createElement('link');
                link.type = 'text/css';
                link.href = href;
                link.rel = 'stylesheet';
                document.head.appendChild(link);
            }
    
            loadStyle('https://cdnjs.cloudflare.com/ajax/libs/mediaelement/2.13.2/css/mediaelementplayer.min.css');
            loadScript('https://cdnjs.cloudflare.com/ajax/libs/mediaelement/2.13.2/js/mediaelement-and-player.min.js');
    
            setTimeout(() => {
                @if($item->media_type == 'Video' || $item->media_type == 'Url_Media')
                    var player_ads = new MediaElementPlayer('#player_ads', {
                        stretching: 'responsive'
                    });
                @endif  
            }, 1500);

        });
    </script>
@endif
@endhasrole
