<?php

return [

    'name_22'              => 'InternalAdvertising --!!!',
    'description'       => 'This is my awesome module',

];