<?php

namespace Modules\InternalAdvertising\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InternalAdvertisingResource extends JsonResource
{
    public function toArray($request)
    {        
        return [
            "enable" => $this->enable,
            "url_to_redirect" => $this->url_to_redirect,
            "start_date" => $this->start_date,
            "end_date" => $this->end_date,
            "media_type" => $this->media_type,
            "url_media" => $this->url_media,
            "mime" => $this->getMimeType($this->media_type, $this->url_media),            
        ];
    }

    public function getMimeType($media_type, $filePath) {
        if($media_type == 'Image' || $media_type == 'Video'){
            return mime_content_type(public_path($filePath));
        }
        return '----';
    }
}
