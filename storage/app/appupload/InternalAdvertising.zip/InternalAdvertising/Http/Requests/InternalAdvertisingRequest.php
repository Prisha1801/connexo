<?php

namespace Modules\InternalAdvertising\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class InternalAdvertisingRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {        
        $rules = [];

        if($this->method() === 'POST')
        {
            $rules['enable'] = 'required|boolean';
            $rules['media_type'] = [
                'required',
                Rule::in(['Image', 'Video', 'Url_Media']),
            ];

            if(request()->has('media_type')){
                if(request('media_type') === 'Image'){
                    $rules['file_media'] = 'required|image|mimes:png,jpg,jpeg|max:5120';
                }
                if(request('media_type') === 'Video'){
                    $rules['file_media'] = 'required|mimes:mp4,ogx,oga,ogv,ogg,webm,mkv,avi|max:8192';
                }
                if(request('media_type') === 'Url_Media'){
                    $rules['url_media'] = 'required|url';
                }
            }

            if(request()->has('url_to_redirect')){
                if(request('url_to_redirect') !== null){
                    $rules['url_to_redirect'] = 'url';
                }
            }

            if(request()->has('start_date')){
                if(request('start_date') !== null){
                    $rules['start_date'] = 'date|after_or_equal:today';
                }
            }
            
            if(request()->has('end_date')){
                if(request('end_date') !== null)
                {
                    if(request()->has('start_date')){
                        if(request('start_date') !== null){                            
                            $rules['end_date'] = 'date|after_or_equal:start_date|after_or_equal:today';
                        }else{
                            $rules['end_date'] = 'date|after_or_equal:today';
                        }
                    }
                }
            }
        }

        if($this->method() === 'PUT' || $this->method() === 'PATCH')
        {
            $rules['enable'] = 'required|boolean';
            $rules['media_type'] = [
                'required',
                Rule::in(['Image', 'Video', 'Url_Media']),
            ];
            
            if(request('media_type') === 'Image'){
                $rules['file_media'] = 'image|mimes:png,jpg,jpeg|max:5120';
            }
            if(request('media_type') === 'Video'){
                $rules['file_media'] = 'mimes:mp4,ogx,oga,ogv,ogg,webm,mkv,avi|max:8192';
            }
            if(request('media_type') === 'Url_Media'){
                $rules['url_media'] = 'url';
            }            

            if(request()->has('url_to_redirect')){
                if(request('url_to_redirect') !== null){
                    $rules['url_to_redirect'] = 'url';
                }
            }

            if(request()->has('start_date')){
                if(request('start_date') !== null){
                    $rules['start_date'] = 'date|after_or_equal:today';
                }
            }
            
            if(request()->has('end_date')){
                if(request('end_date') !== null)
                {
                    if(request()->has('start_date')){
                        if(request('start_date') !== null){                            
                            $rules['end_date'] = 'date|after_or_equal:start_date|after_or_equal:today';
                        }else{
                            $rules['end_date'] = 'date|after_or_equal:today';
                        }
                    }
                }
            }
        }

   
        

        return $rules;
    }

    public function authorize()
    {
        return true;
    }

    public function attributes()
    {
        return [
            "enable" => trans('internal_advertising.Habilitar'), 
            "media_type" => trans('internal_advertising.media_type'), 
            "file_media" => trans('internal_advertising.upload_file'),
            "url_media" => trans('internal_advertising.url_media'),
            "url_to_redirect" => trans('internal_advertising.url_to_redirect'),
            "start_date" => trans('internal_advertising.start_date'),
            "end_date" => trans('internal_advertising.end_date')
        ];
    }
}
