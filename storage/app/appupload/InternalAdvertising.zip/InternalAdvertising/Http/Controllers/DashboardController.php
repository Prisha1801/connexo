<?php

namespace Modules\InternalAdvertising\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use Modules\InternalAdvertising\Models\InternalAdvertising;

class DashboardController extends Controller
{

    public function index()
    {
        $data = [];

        $data['show_data'] = true;
        
        //verifica si hay data de ads en BD
        $adss = InternalAdvertising::where('enable', true)
                    ->where(function ($query){
                        return $query->whereNull('start_date')
                        ->orWhere('start_date', '<=', now());
                    })
                    ->where(function ($query){
                        return $query->whereNull('end_date')
                        ->orWhere('end_date', '>=', now());
                   })->count();
        
        if($adss == 0){
            request()->session()->forget('internal_ads');
            $data['show_data'] = false;
            return ['data' => $data];
        }
        
        if(request()->session()->has('internal_ads')){
            $ads = request()->session()->get('internal_ads');
            $ads['turns'] = $ads['turns'] - 1;
            
            if($ads['turns']==0){
                if($adss > 1){
                    $model = InternalAdvertising::where('id', '!=', $ads['id'])
                    ->where('enable', true)
                    ->where(function ($query){
                        return $query->whereNull('start_date')
                        ->orWhere('start_date', '<=', now());
                    })
                    ->where(function ($query){
                        return $query->whereNull('end_date')
                        ->orWhere('end_date', '>=', now());
                    })
                    ->inRandomOrder()->first(); 
                }else{
                    $model = InternalAdvertising::where('enable', true)
                    ->where(function ($query){
                        return $query->whereNull('start_date')
                        ->orWhere('start_date', '<=', now());
                    })
                    ->where(function ($query){
                        return $query->whereNull('end_date')
                        ->orWhere('end_date', '>=', now());
                    })
                    ->inRandomOrder()->first(); 
                }
                

                $ads = [
                    'id' => $model->id,
                    'turns' => rand(2,6)
                ];
            }
            request()->session()->put('internal_ads', $ads);
            $data['ads'] = $ads;
        }else{
            $model = InternalAdvertising::where('enable', true)
                ->where(function ($query){
                    return $query->whereNull('start_date')
                    ->orWhere('start_date', '<=', now());
                })
                ->where(function ($query){
                    return $query->whereNull('end_date')
                    ->orWhere('end_date', '>=', now());
                })
                ->inRandomOrder()->first();  

            $ads = [
                'id' => $model->id,
                'turns' => rand(2,6)
            ];

            request()->session()->put('internal_ads', $ads);

            $data['ads'] = $ads;
        }

        $data['model_ads'] = InternalAdvertising::where('id', $ads['id'])->first();

        return [
            'data' => $data
        ];
    }

}
