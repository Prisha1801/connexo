<?php

namespace Modules\InternalAdvertising\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\InternalAdvertising\Http\Requests\InternalAdvertisingRequest;
use Modules\InternalAdvertising\Models\InternalAdvertising;
use Modules\InternalAdvertising\Http\Resources\InternalAdvertisingResource;

class InternalAdvertisingController extends Controller
{
    /**
     * Provide class.
     */
    private $provider = InternalAdvertising::class;

    /**
     * Title of this crud in plural.
     */
    private $titlePlural = 'Internal advertisings';

    public function authAdminChecker()
    {        
        if (!auth()->user()->hasRole('admin')) {
            abort(403, 'Unauthorized action.');
        }
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        $this->authAdminChecker();

        //no esta ejecutando el resource!!!! error super extraño revisar        
        return view('internal_advertising::index', [                                  
            'items' => InternalAdvertisingResource::collection(InternalAdvertising::paginate()) ,            
        ]);

    }

    public function create()
    {
        $this->authAdminChecker();

        return view('internal_advertising::create');
    }

    public function store(InternalAdvertisingRequest $request)
    {
        $this->authAdminChecker();

        $data = [
            'enable' => $request->enable,
            'media_type' => $request->media_type,
            'url_to_redirect' => $request->url_to_redirect,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ];

        if(request('media_type') === 'Image' || request('media_type') === 'Video'){
            $imageName = time().'.'.$request->file_media->extension();
            $request->file_media->move(public_path('uploads/internal_advertising'), $imageName);
            $data['url_media'] = 'uploads/internal_advertising/'.$imageName;
        }

        if(request('media_type') === 'Url_Media'){
            $data['url_media'] = $request->url_media;            
        }

        $this->provider::create($data);

        return redirect()->route('internal_advertising.index');
    }

    public function show($id)
    {
        return view('internal_advertising::show');
    }

    public function edit($id)
    {
        $this->authAdminChecker();

        $model = $this->provider::findOrFail($id);  
        
        return view('internal_advertising::edit', ['model' => $model]);
    }

    public function update(InternalAdvertisingRequest $request, $id)
    {
        $this->authAdminChecker();

        $model = $this->provider::findOrFail($id); 

        $model->enable = $request->enable;
        $model->url_to_redirect = $request->url_to_redirect;
        $model->start_date = $request->start_date;
        $model->end_date = $request->end_date;

        if(($request->file_media !== null || $request->url_media !== $model->url_media)){
            if(File::exists(public_path($model->url_media))){
                File::delete(public_path($model->url_media));
            }

            if((request('media_type') === 'Image' || request('media_type') === 'Video')){
                $imageName = time().'.'.$request->file_media->extension();           
                $request->file_media->move(public_path('uploads/internal_advertising'), $imageName);
                $model->url_media = 'uploads/internal_advertising/'.$imageName;
            }else{
                $model->url_media = $request->url_media;
            }
        }        

        $model->media_type = $request->media_type;

        $model->update();
        
        return redirect()->route('internal_advertising.index');
    }

    public function destroy($id)
    {
        $this->authAdminChecker();

        $model = $this->provider::findOrFail($id);  

        if($model->media_type === 'Image' || $model->media_type === 'Video'){
            if(File::exists(public_path($model->url_media))){
                File::delete(public_path($model->url_media));
            }
        }

        $model->delete();

        return redirect()->route('internal_advertising.index');
    }

    public function adsShow()
    {
        return view('internal_advertising::ads_show');
    }
}
