<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group([    
    'namespace' => 'Modules\InternalAdvertising\Http\Controllers'
],function() {
    Route::prefix('internal_advertising')->group(function() {
        Route::get('/ads_show', 'InternalAdvertisingController@adsShow')->name('internal_advertising.ads');    
    });
});


Route::group([
    'middleware' =>[ 'web', 'auth', 'impersonate'],
    'namespace' => 'Modules\InternalAdvertising\Http\Controllers'
],function() {
    
    Route::prefix('internal_advertising')->group(function() {
        Route::get('/list', 'InternalAdvertisingController@index')->name('internal_advertising.index');
        Route::get('/{id}/edit', 'InternalAdvertisingController@edit')->name('internal_advertising.edit');
        Route::get('/create', 'InternalAdvertisingController@create')->name('internal_advertising.create');
        Route::post('/', 'InternalAdvertisingController@store')->name('internal_advertising.store');
        Route::put('/{id}', 'InternalAdvertisingController@update')->name('internal_advertising.update');
        Route::delete('/del/{id}', 'InternalAdvertisingController@destroy')->name('internal_advertising.delete');
    });

});