<?php

return [
    'name' => 'InternalAdvertising'
];
