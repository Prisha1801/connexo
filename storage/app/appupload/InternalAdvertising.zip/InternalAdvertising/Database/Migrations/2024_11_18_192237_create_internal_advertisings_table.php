<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInternalAdvertisingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('internal_advertisings', function (Blueprint $table) {
            $table->bigIncrements('id');            
            $table->enum('media_type', ['Image', 'Video', 'Url_Media']);
            $table->string('url_media', 255);
            $table->string('url_to_redirect', 255)->nullable();
            $table->boolean('enable')->default(true);
            $table->timestamp('start_date')->nullable();
            $table->timestamp('end_date')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('internal_advertisings');
    }
}
