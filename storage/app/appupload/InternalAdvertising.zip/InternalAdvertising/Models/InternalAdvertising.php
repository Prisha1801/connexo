<?php

namespace Modules\InternalAdvertising\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class InternalAdvertising extends Model
{
    use HasFactory;

    protected $fillable = ['url_media', 'url_to_redirect', 'enable', 'media_type', 'start_date', 'end_date'];

    protected $casts = [
        'start_date' => 'datetime:Y-m-d',
        'end_date' => 'datetime:Y-m-d',
    ];
}
