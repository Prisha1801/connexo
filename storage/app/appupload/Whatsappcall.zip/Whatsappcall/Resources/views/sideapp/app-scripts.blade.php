<script>
document.addEventListener('DOMContentLoaded', function(){
  const logs = document.getElementById('waCallLogs');
  function logLine(obj, level='info'){
    if(!logs) return;
    const time = new Date().toISOString();
    const line = document.createElement('div');
    line.style.whiteSpace = 'pre-wrap';
    line.textContent = `[${time}] [${level}] ` + (typeof obj === 'string' ? obj : JSON.stringify(obj));
    logs.appendChild(line);
    logs.scrollTop = logs.scrollHeight;
  }

  const reqForm = document.getElementById('waRequestPermissionForm');
  if(reqForm){
    reqForm.addEventListener('submit', async function(e){
      e.preventDefault();
      try{
        logLine('Requesting call permission...');
        const formData = new FormData(reqForm);
        const res = await fetch(reqForm.action, { method:'POST', body: formData, headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }, credentials: 'same-origin' });
        const json = await res.json().catch(() => ({}));
        logLine({ status: res.status, body: json });
        if(window.js && js.notify){ js.notify('Permission request sent', res.ok ? 'success' : 'danger'); }
      }catch(err){ logLine(err?.message || err, 'error'); }
    });
  }

  const startForm = document.getElementById('waStartCallForm');
  if(startForm){
    startForm.addEventListener('submit', async function(e){
      e.preventDefault();
      try{
        logLine('Starting business-initiated call...');
        const formData = new FormData(startForm);
        const res = await fetch(startForm.action, { method:'POST', body: formData, headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }, credentials: 'same-origin' });
        const json = await res.json().catch(() => ({}));
        logLine({ status: res.status, body: json });
        if(json?.link){
          logLine('Call link: ' + json.link);
          if(window.open){ window.open(json.link, '_blank'); }
        }
        if(window.js && js.notify){ js.notify(res.ok ? 'Call initiated' : 'Call initiate failed', res.ok ? 'success' : 'danger'); }
      }catch(err){ logLine(err?.message || err, 'error'); }
    });
  }
});
</script>
