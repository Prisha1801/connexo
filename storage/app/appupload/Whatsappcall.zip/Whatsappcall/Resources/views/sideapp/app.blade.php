<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span>Whatsapp Call</span>
        <form id="waRequestPermissionForm" method="POST" action="{{ route('whatsappcall.bic.request') }}" class="mb-0">
            @csrf
            <input type="hidden" name="contact_id" value="{{ $contact->id ?? '' }}" />
            <button class="btn btn-sm btn-primary">Request permission</button>
        </form>
    </div>
    <div class="card-body">
        <form id="waStartCallForm" method="POST" action="{{ route('whatsappcall.bic.start') }}">
            @csrf
            <input type="hidden" name="contact_id" value="{{ $contact->id ?? '' }}" />
            <button class="btn btn-success w-100">Start call</button>
        </form>
        <hr>
        <p class="text-muted small">UIC will appear when your number has calling enabled and users call you from their WhatsApp app. Ensure calling webhooks are subscribed.</p>

        <a href="{{ route('whatsappcall.settings') }}" class="btn btn-link btn-sm p-0">Calling settings</a>

        <div id="waCallLogs" class="mt-3" style="max-height: 240px; overflow:auto; background:#0b1021; color:#d1d5db; border-radius:8px; padding:10px; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; font-size: 12px;"></div>
    </div>
</div>

<h5 class="text-muted mt-4">{{ __('Whatsapp Call')}}</h5>
<div class="contacInfo border-radius-lg border p-4 mb-4">
    <div class="mb-3">
        <label class="form-label">{{ __('Recipient Phone Number') }}</label>
        <div class="form-control-plaintext"><strong>@{{ activeChat.phone }}</strong></div>
    </div>
</div>

@section('js')
  @include('whatsappcall::sideapp.app-scripts')
@endsection